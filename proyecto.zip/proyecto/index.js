const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2');  // Requerir el módulo mysql2
const app = express();
const port = 3001;

// Middleware para permitir recibir JSON en las peticiones
app.use(express.json());

// Base de datos temporal (en memoria) de usuarios
let users = [
  { id: 1, name: 'John Doe' },
  { id: 2, name: 'Jane Doe' }
];

// Ruta raíz ("/")
app.get('/', (req, res) => {
  res.send('¡Bienvenido a la API de gestión de usuarios!');
});

// Obtener todos los usuarios
app.get('/api/users', (req, res) => {
  res.json(users);
});

// Obtener un usuario por ID
app.get('/api/users/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const user = users.find(u => u.id === userId);

  if (!user) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  res.json(user);
});

// Crear un nuevo usuario
app.post('/api/users', (req, res) => {
  const newUser = {
    id: users.length + 1,
    name: req.body.name
  };
  users.push(newUser);
  res.status(201).json(newUser);
});

// Actualizar un usuario existente
app.put('/api/users/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const userIndex = users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  users[userIndex].name = req.body.name;
  res.json(users[userIndex]);
});

// Eliminar un usuario
app.delete('/api/users/:id', (req, res) => {
  const userId = parseInt(req.params.id);
  const userIndex = users.findIndex(u => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: 'Usuario no encontrado' });
  }

  const deletedUser = users.splice(userIndex, 1);
  res.json(deletedUser);
});

// Manejador de errores global
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Algo salió mal!');
});

// Levantar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
