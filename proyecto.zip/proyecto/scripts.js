function saludar() {
    alert('¡Hola, usuario!');
  }
  