const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2');  // Requerir el módulo mysql2
const app = express();
const port = 3006;

// Simularemos una "sesión" simple para verificar si el usuario está logueado
let isAuthenticated = false;

// Conectar a la base de datos MySQL
const db = mysql.createConnection({
  host: 'localhost',  // Cambia según tu configuración
  user: 'root',          // Cambia según tu configuración
  password: '',  // Cambia según tu configuración
  database: 'tienda'     // Nombre de la base de datos
});

db.connect((err) => {
  if (err) {
    console.error('Error conectando a la base de datos:', err);
  } else {
    console.log('Conectado a la base de datos MySQL');
  }
});

// Middleware para servir archivos estáticos (CSS, JS)
app.use(express.static(__dirname));

// Middleware para analizar el cuerpo de las solicitudes POST
app.use(bodyParser.urlencoded({ extended: true }));

// Ruta principal para servir la página de login
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Ruta para manejar el login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Validación básica (usuario y contraseña fijos)
  if (username === 'admin' && password === '1234') {
    isAuthenticated = true;  // Marcamos al usuario como autenticado
    res.redirect('/productos');  // Redirigimos a la página de productos
  } else {
    res.send('<h1>¡Login fallido!</h1><p>Usuario o contraseña incorrectos.</p>');
  }
});

// Ruta para servir la página de registro de productos
app.get('/productos', (req, res) => {
  if (isAuthenticated) {
    res.sendFile(path.join(__dirname, 'productos.html'));
  } else {
    res.send('<h1>No autorizado</h1><p>Por favor, inicie sesión primero.</p>');
  }
});

// Ruta para manejar el registro de productos
app.post('/productos', (req, res) => {
  if (isAuthenticated) {
    const { nombreProducto, precioProducto } = req.body;

    // Insertar producto en la base de datos
    const query = 'INSERT INTO productos (nombre, precio) VALUES (?, ?)';
    db.query(query, [nombreProducto, precioProducto], (err, result) => {
      if (err) {
        console.error('Error al insertar producto:', err.sqlMessage);
        res.send('<h1>Error al registrar el producto.</h1>');
      } else {
        res.send(`<h1>¡Producto registrado!</h1><p>Producto: ${nombreProducto}, Precio: ${precioProducto}</p>
                  <a href="/productos">Registrar otro producto</a><br>
                  <a href="/">Cerrar sesión</a>`);
      }
    });
  } else {
    res.send('<h1>No autorizado</h1><p>Por favor, inicie sesión primero.</p>');
  }
});


// Ruta para obtener todos los productos
app.get('/productos/listar', (req, res) => {
  if (isAuthenticated) {
    const query = 'SELECT * FROM productos';
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al obtener productos:', err);
        res.status(500).send('Error al obtener productos');
      } else {
        res.json(results);
      }
    });
  } else {
    res.status(403).send('No autorizado');
  }
});

// Ruta para actualizar un producto
app.post('/productos/:id', (req, res) => {
  if (isAuthenticated) {
    const id = req.params.id;
    const { nombreProducto, precioProducto } = req.body;
    const query = 'UPDATE productos SET nombre = ?, precio = ? WHERE id = ?';

    db.query(query, [nombreProducto, precioProducto, id], (err, result) => {
      if (err) {
        console.error('Error al actualizar producto:', err);
        res.send('<h1>Error al actualizar el producto.</h1>');
      } else {
        res.send('<h1>¡Producto actualizado!</h1><a href="/productos">Volver a productos</a>');
      }
    });
  } else {
    res.send('<h1>No autorizado</h1><p>Por favor, inicie sesión primero.</p>');
  }
});

// Ruta para eliminar un producto
app.delete('/productos/:id', (req, res) => {
  if (isAuthenticated) {
    const id = req.params.id;
    const query = 'DELETE FROM productos WHERE id = ?';

    db.query(query, [id], (err, result) => {
      if (err) {
        console.error('Error al eliminar producto:', err);
        res.status(500).send('Error al eliminar producto');
      } else {
        res.status(204).send();  // No content
      }
    });
  } else {
    res.status(403).send('No autorizado');
  }
});


// Ruta para consultar productos
app.get('/consultar-productos', (req, res) => {
  if (isAuthenticated) {
    const query = 'SELECT * FROM productos';
    db.query(query, (err, results) => {
      if (err) {
        console.error('Error al obtener los productos:', err);
        res.status(500).send('Error al consultar los productos.');
      } else {
        res.json(results); // Devolver los productos como un JSON
      }
    });
  } else {
    res.status(401).send('No autorizado. Por favor, inicie sesión primero.');
  }
});

// Ruta para consultar producto por nombre
app.get('/consultar-producto/nombre/:nombre', (req, res) => {
  const nombreProducto = req.params.nombre;
  
  if (isAuthenticated) {
    const query = 'SELECT * FROM productos WHERE nombre = ?';
    db.query(query, [nombreProducto], (err, results) => {
      if (err) {
        console.error('Error al consultar producto por nombre:', err);
        res.status(500).send('Error al consultar el producto.');
      } else if (results.length === 0) {
        res.send('No se encontró ningún producto con ese nombre.');
      } else {
        res.json(results); // Devolver los resultados como JSON
      }
    });
  } else {
    res.status(401).send('No autorizado. Por favor, inicie sesión primero.');
  }
});


// Ruta para consultar producto por ID
app.get('/consultar-producto/id/:id', (req, res) => {
  const idProducto = req.params.id;
  
  if (isAuthenticated) {
    const query = 'SELECT * FROM productos WHERE id = ?';
    db.query(query, [idProducto], (err, results) => {
      if (err) {
        console.error('Error al consultar producto por ID:', err);
        res.status(500).send('Error al consultar el producto.');
      } else if (results.length === 0) {
        res.send('No se encontró ningún producto con ese ID.');
      } else {
        res.json(results); // Devolver los resultados como JSON
      }
    });
  } else {
    res.status(401).send('No autorizado. Por favor, inicie sesión primero.');
  }
});


// Ruta para cerrar sesión
app.get('/logout', (req, res) => {
  isAuthenticated = false;  // Cerramos la sesión
  res.redirect('/');
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});